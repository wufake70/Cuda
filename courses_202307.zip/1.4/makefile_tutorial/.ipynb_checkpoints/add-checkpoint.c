float addition(float a, float b)
{
    return (a+b);
}
