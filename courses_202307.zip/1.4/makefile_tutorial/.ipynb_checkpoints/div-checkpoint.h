#ifndef DIVISION_H
#define DIVISION_H

float division(float a, float b);
#endif/*DIVISION_H*/
